<?php

namespace Modules\NsCustomFields;

class NsCustomFieldsModule
{
    // Module entry class - can be empty
}
